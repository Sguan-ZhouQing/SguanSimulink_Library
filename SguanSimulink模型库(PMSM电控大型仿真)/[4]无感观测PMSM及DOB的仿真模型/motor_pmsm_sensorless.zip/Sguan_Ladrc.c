/*
 * @Author: 星必尘Sguan
 * @GitHub: https://github.com/Sguan-ZhouQing
 * @Date: 2026-02-16  00:27:53
 * @LastEditors: 星必尘Sguan|3464647102@qq.com
 * @LastEditTime: 2026-04-22 15:25:03
 * @FilePath: \SguanFOC_Debug\SguanFOC\Sguan_Ladrc.c
 * @Description: SguanFOC库的“二阶线性自适应抗干扰控制(LADRC)算法”实现
 * 
 * Copyright (c) 2026 by 星必尘Sguan, All Rights Reserved. 
 */
#include "Sguan_Ladrc.h"

// 静态函数声明 - LADRC核心算法的三个步骤
static void Ladrc_LTD(LADRC_STRUCT *ladrc);
static void Ladrc_LESO(LADRC_STRUCT *ladrc);
static void Ladrc_LinearControlRate(LADRC_STRUCT *ladrc);

static void Value_Limit(float *val, float max, float min);

// 数值限幅float函数
static void Value_Limit(float *val, float max, float min){
    if (*val > max) *val = max;
    if (*val < min) *val = min;
}

// 线性跟踪微分器(LTD) - 安排过渡过程
static void Ladrc_LTD(LADRC_STRUCT *ladrc){
    // 最速控制综合函数 fh = -r^2*(v1-Ref) - 2*r*v2
    ladrc->run.fh = -ladrc->r*ladrc->r*(ladrc->run.v1 - ladrc->run.Ref) 
                    -2.0f*ladrc->r*ladrc->run.v2;
    
    // 离散化更新 v1 = v1 + h*v2, v2 = v2 + h*fh
    ladrc->run.v1 += ladrc->run.v2*ladrc->T;
    ladrc->run.v2 += ladrc->run.fh*ladrc->T;
}

// 线性扩张状态观测器(LESO) - 估计系统状态和总扰动
static void Ladrc_LESO(LADRC_STRUCT *ladrc){
    // 观测器误差 e = z1 - Fbk
    ladrc->run.e = ladrc->run.z1 - ladrc->run.Fbk;
    
    /* 扩张状态观测器离散方程
     * z1 += (z2 - beta01*e) * h
     * z2 += (z3 - beta02*e + b0*u_sat) * h
     * z3 += (-beta03*e) * h
     */
    ladrc->run.z1 += (ladrc->run.z2 - ladrc->data.beta1*ladrc->run.e)*ladrc->T;
    ladrc->run.z2 += (ladrc->run.z3 - ladrc->data.beta2*ladrc->run.e 
                     + ladrc->b0*ladrc->run.Output)*ladrc->T;
    ladrc->run.z3 += (-ladrc->data.beta3*ladrc->run.e)*ladrc->T;
}

// 线性控制率(LSEF/LF) - 计算控制量
static void Ladrc_LinearControlRate(LADRC_STRUCT *ladrc){
    // 误差计算 e1 = v1 - z1, e2 = v2 - z2
    ladrc->run.e1 = ladrc->run.v1 - ladrc->run.z1;
    ladrc->run.e2 = ladrc->run.v2 - ladrc->run.z2;
    
    // 线性反馈控制率 u0 = Kp*e1 + Kd*e2
    ladrc->run.u0 = ladrc->data.Kp*ladrc->run.e1 + 
                        ladrc->data.Kd*ladrc->run.e2;
    
    // 扰动补偿 u = (u0 - z3) / b0
    ladrc->run.Output = (ladrc->run.u0 - ladrc->run.z3)/ladrc->b0;
    
    // 输出限幅
    Value_Limit(&ladrc->run.Output, 
                ladrc->OutMax, 
                ladrc->OutMin);
}

/**
 * @description: LADRC核心参数初始化
 * @param {LADRC_STRUCT} *ladrc LADRC结构体指针
 * @return {void}
 */
void Ladrc_Init(LADRC_STRUCT *ladrc){
    // 控制器参数设置
    ladrc->data.w0 = 4.0f*ladrc->wc;     // 观测器带宽
    
    // 计算观测器系数
    ladrc->data.beta1 = 3.0f*ladrc->data.w0;
    ladrc->data.beta2 = 3.0f*ladrc->data.w0*ladrc->data.w0;
    ladrc->data.beta3 = ladrc->data.w0*ladrc->data.w0*ladrc->data.w0;
    
    // 计算控制器系数
    ladrc->data.Kp = ladrc->wc*ladrc->wc;
    ladrc->data.Kd = 2.0f*ladrc->wc;
    
    // 默认输出限幅
    ladrc->OutMax = 2000.0f;
    ladrc->OutMin = -2000.0f;
    
    // 初始化所有运行变量为零
    ladrc->run.v1 = 0.0f;
    ladrc->run.v2 = 0.0f;
    ladrc->run.z1 = 0.0f;
    ladrc->run.z2 = 0.0f;
    ladrc->run.z3 = 0.0f;
    ladrc->run.Ref = 0.0f;
    ladrc->run.Fbk = 0.0f;
    ladrc->run.Output = 0.0f;
    ladrc->run.e = 0.0f;
    ladrc->run.e1 = 0.0f;
    ladrc->run.e2 = 0.0f;
    ladrc->run.u0 = 0.0f;
    ladrc->run.fh = 0.0f;
}

/**
 * @description: LADRC主循环函数(定时器中断中调用)
 * @param {LADRC_STRUCT} *ladrc LADRC结构体指针
 * @return {void}
 */
void Ladrc_Loop(LADRC_STRUCT *ladrc){
    // 1.跟踪微分器 - 安排过渡过程
    Ladrc_LTD(ladrc);
    
    // 2.扩张状态观测器 - 估计状态和扰动
    Ladrc_LESO(ladrc);
    
    // 3.线性控制率 - 计算控制量
    Ladrc_LinearControlRate(ladrc);
}

LADRC_STRUCT LADRC;

void L_Init(void){
    LADRC.T = 1e-4;
    LADRC.wc = 200.0f;
    LADRC.r = 50.0f;
    LADRC.b0 = 30000.0f;
    LADRC.OutMax = 1e20;
    LADRC.OutMin = -1e20;
    Ladrc_Init(&LADRC);
}

void L_Loop(float Ref,float Fbk,float *Out){
    LADRC.run.Ref = Ref;
    LADRC.run.Fbk = Fbk;
    Ladrc_Loop(&LADRC);
    *Out = LADRC.run.Output;
}

